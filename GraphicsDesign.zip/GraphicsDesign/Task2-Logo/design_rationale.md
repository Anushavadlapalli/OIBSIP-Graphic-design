# Design Rationale - NEXORA
Deep navy conveys trust and technical depth, while the amber dot signals the spark of innovation and the "next" step forward.
The symbol is a bold letter N inside a circle: a single continuous stroke that reads as an upward zig-zag, representing growth and connectivity.
Kept deliberately minimal (KISS) so it scales from a favicon to a billboard. Typeface: Poppins (geometric sans-serif) for a modern, friendly tech feel.
