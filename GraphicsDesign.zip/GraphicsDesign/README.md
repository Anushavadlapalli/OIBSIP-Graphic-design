# Graphics Design - OIBSIP (4 tasks)
| Task | Folder | Deliverables |
|---|---|---|
| 1. Posters & Fliers | Task1-Posters | 2 posters, 1080x1080 PNG + PDF + SVG source |
| 2. Logo Design | Task2-Logo | NEXORA logo: full colour, monochrome, reversed; SVG + PNG 1000x1000 (transparent); design_rationale.md |
| 3. Business Card | Task3-BusinessCard | 85x55mm + 3mm bleed, front/back PDF (print-ready), PNG preview |
| 4. Infographic | Task4-Infographic | 800x2000 PNG (+1600x4000 hi-res @150 DPI), SVG source, sources cited |

Tools: SVG hand-coded + rendered with Python/CairoSVG. Font: Poppins (Google Fonts). Palette: navy #0B1F3A, teal #1FB5A8, amber #FFB84D, white.
